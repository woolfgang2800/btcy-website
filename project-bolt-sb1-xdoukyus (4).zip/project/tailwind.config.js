/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#D4AF37', // Gold
        secondary: '#4A00E0', // Deep purple
        accent: '#00B4FF', // Electric blue
        background: {
          DEFAULT: '#080808', // Matte black
          light: '#121212',
          dark: '#050505',
        },
        success: '#00C896',
        warning: '#FFB800',
        error: '#FF4A4A',
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'grid-pattern': 'linear-gradient(rgba(26, 26, 26, 0.15) 1.5px, transparent 1.5px), linear-gradient(to right, rgba(26, 26, 26, 0.15) 1.5px, transparent 1.5px)',
      },
      backgroundSize: {
        'grid': '30px 30px',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
};