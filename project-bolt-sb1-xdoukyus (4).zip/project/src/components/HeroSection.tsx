import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from './ui/Button';
import { TypeAnimation } from 'react-type-animation';

export const HeroSection: React.FC = () => {
  return (
    <section className="min-h-screen flex items-center pt-20 pb-16 overflow-hidden relative">
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="font-orbitron text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
              <span className="text-primary">Fueling</span> Bitcoin Growth
            </h1>
            <div className="h-16 mb-6">
              <TypeAnimation
                sequence={[
                  'Gold & Silver Backed',
                  2000,
                  'Yield Generating Asset',
                  2000,
                  'Advanced AI Accounting',
                  2000,
                ]}
                wrapper="div"
                cursor={true}
                repeat={Infinity}
                className="text-xl md:text-2xl text-white/80"
              />
            </div>
            <p className="text-white/70 text-lg mb-8 max-w-xl">
              BTCY is a crypto asset linked to the growth of Bitcoin and backed by gold and silver reserves.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button as={Link} to="/onboarding" variant="primary" size="lg">
                Get Started
              </Button>
              <Button as={Link} to="/staking" variant="outline" size="lg">
                Stake BTCY
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="flex justify-center"
          >
            <div className="relative">
              <motion.img
                src="https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Bitcoin Gold Coin"
                className="max-w-full h-auto rounded-lg shadow-[0_0_50px_rgba(212,175,55,0.15)]"
                animate={{ y: [0, -10, 0] }}
                transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
              />
              <div className="absolute inset-0 rounded-lg shadow-inner border border-primary/20 bg-gradient-to-t from-background/80 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-background to-transparent z-[1]"></div>
    </section>
  );
};