import React from 'react';
import { Link } from 'react-router-dom';
import { Bitcoin, Twitter, Mail, MessageSquare } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-background-dark border-t border-white/5 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2">
              <Bitcoin className="text-primary w-8 h-8" />
              <span className="font-orbitron text-xl font-bold text-white">
                <span className="text-primary">BTC</span>Y
              </span>
            </Link>
            <p className="mt-4 text-white/60 text-sm">
              Bitcoin Yield is a crypto asset linked to the growth of Bitcoin and backed by gold and silver reserves.
            </p>
          </div>

          <div className="md:col-span-1">
            <h3 className="font-orbitron text-white text-lg mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/tokenomics" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Tokenomics
                </Link>
              </li>
              <li>
                <Link to="/staking" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Staking
                </Link>
              </li>
              <li>
                <Link to="/whitepaper" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Whitepaper
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-1">
            <h3 className="font-orbitron text-white text-lg mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/terms" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/disclaimer" className="text-white/60 hover:text-primary transition-colors text-sm">
                  Risk Disclaimer
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-1">
            <h3 className="font-orbitron text-white text-lg mb-4">Connect</h3>
            <div className="flex space-x-4 mb-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/60 hover:text-primary transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a
                href="https://t.me"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/60 hover:text-primary transition-colors"
                aria-label="Telegram"
              >
                <MessageSquare size={20} />
              </a>
              <a
                href="mailto:btcycrypto@proton.me"
                className="text-white/60 hover:text-primary transition-colors"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
            <p className="text-white/60 text-sm">
              Email: btcycrypto@proton.me
            </p>
          </div>
        </div>

        <div className="mt-12 pt-4 border-t border-white/5 text-center">
          <p className="text-white/40 text-xs">
            &copy; 2025 BTCY | All rights reserved
          </p>
        </div>
      </div>
    </footer>
  );
};