import React, { useState, useEffect } from 'react';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { ParticleBackground } from './ParticleBackground';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-background bg-grid-pattern relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background pointer-events-none"></div>
      <Navbar scrolled={scrolled} />
      <main className="flex-grow relative">
        <ParticleBackground />
        <div className="relative z-10">
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
};