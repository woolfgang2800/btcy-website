import React, { useState } from 'react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Check } from 'lucide-react';

export const KYCForm: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    country: '',
    walletAddress: '',
    termsAccepted: false
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const checked = type === 'checkbox' ? (e.target as HTMLInputElement).checked : undefined;
    
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(step + 1);
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(3); // Success page
  };

  return (
    <Card className="max-w-md mx-auto">
      <div className="mb-6">
        <div className="flex justify-between items-center">
          {[1, 2, 3].map((s) => (
            <div 
              key={s} 
              className={`relative flex items-center justify-center w-8 h-8 rounded-full ${
                s < step ? 'bg-primary text-background' : 
                s === step ? 'bg-primary/20 text-primary border border-primary' : 
                'bg-background-dark text-white/40'
              }`}
            >
              {s < step ? <Check size={16} /> : s}
              
              <div className={`absolute -bottom-6 whitespace-nowrap text-xs ${
                s === step ? 'text-primary' : 'text-white/40'
              }`}>
                {s === 1 ? 'Personal Info' : s === 2 ? 'Wallet' : 'Complete'}
              </div>
              
              {s < 3 && (
                <div className={`absolute top-1/2 left-full w-full h-[2px] ${
                  s < step ? 'bg-primary' : 'bg-background-dark'
                }`}></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {step === 1 && (
        <form onSubmit={handleNext}>
          <h3 className="font-orbitron text-xl text-center mb-6 mt-8">Personal Information</h3>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-white/60 mb-2 text-sm">First Name</label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                required
                className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
              />
            </div>
            <div>
              <label className="block text-white/60 mb-2 text-sm">Last Name</label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                required
                className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-white/60 mb-2 text-sm">Email Address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-white/60 mb-2 text-sm">Country</label>
            <select
              name="country"
              value={formData.country}
              onChange={handleChange}
              required
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            >
              <option value="">Select country</option>
              <option value="US">United States</option>
              <option value="UK">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="AU">Australia</option>
              <option value="SG">Singapore</option>
              <option value="AE">UAE</option>
              <option value="CH">Switzerland</option>
            </select>
          </div>
          
          <Button type="submit" variant="primary" className="w-full">
            Continue
          </Button>
        </form>
      )}

      {step === 2 && (
        <form onSubmit={handleSubmit}>
          <h3 className="font-orbitron text-xl text-center mb-6 mt-8">Wallet Information</h3>
          
          <div className="mb-6">
            <label className="block text-white/60 mb-2 text-sm">Wallet Address</label>
            <input
              type="text"
              name="walletAddress"
              value={formData.walletAddress}
              onChange={handleChange}
              required
              placeholder="0x..."
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            />
          </div>
          
          <div className="mb-6">
            <label className="flex items-start gap-2">
              <input
                type="checkbox"
                name="termsAccepted"
                checked={formData.termsAccepted}
                onChange={handleChange}
                required
                className="mt-1"
              />
              <span className="text-sm text-white/60">
                I confirm that I have read and agree to the <a href="#" className="text-primary">Terms of Service</a> and <a href="#" className="text-primary">Privacy Policy</a>
              </span>
            </label>
          </div>
          
          <div className="flex gap-4">
            <Button type="button" variant="ghost" onClick={handleBack} className="flex-1">
              Back
            </Button>
            <Button type="submit" variant="primary" className="flex-1">
              Submit
            </Button>
          </div>
        </form>
      )}

      {step === 3 && (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check size={32} className="text-success" />
          </div>
          <h3 className="font-orbitron text-xl mb-2">Verification Submitted</h3>
          <p className="text-white/60 mb-6">
            Your KYC information has been submitted for verification. We will notify you via email once the process is complete.
          </p>
          <Button variant="primary" as="a" href="/" className="w-full">
            Return Home
          </Button>
        </div>
      )}
    </Card>
  );
};