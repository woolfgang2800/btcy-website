import React, { useState } from 'react';
import { Card } from './ui/Card';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer, isOpen, onClick }) => {
  return (
    <div className="border-b border-white/10 last:border-b-0">
      <button
        className="w-full flex justify-between items-center py-4 text-left focus:outline-none"
        onClick={onClick}
      >
        <span className="font-orbitron text-white">{question}</span>
        <span className="text-primary">
          {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </span>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="pb-4 text-white/70">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState(0);
  
  const faqs = [
    {
      question: 'What is BTCY?',
      answer: 'BTCY (Bitcoin Yield) is a crypto asset linked to the growth of Bitcoin and backed by gold and silver reserves. It provides holders with staking opportunities and governance rights within the ecosystem.'
    },
    {
      question: 'How does staking work?',
      answer: 'BTCY staking allows token holders to earn rewards by locking their tokens in the staking contract. The APY ranges from 15-25% depending on the lock period and current network conditions. Rewards are distributed daily and can be claimed at any time.'
    },
    {
      question: 'Is BTCY really backed by physical assets?',
      answer: 'Yes, BTCY is backed by a diversified reserve of Bitcoin, PAXG (gold-backed token), and AGLD (silver-backed token). The reserve is audited quarterly by third-party firms to ensure transparency and compliance.'
    },
    {
      question: 'What is the total supply of BTCY?',
      answer: 'The initial supply of BTCY is 100,000,000 tokens. Through our burn mechanism, we aim to reduce the total supply to 21,000,000 tokens over time, mirroring Bitcoin\'s supply cap.'
    },
    {
      question: 'How do I participate in governance?',
      answer: 'BTCY holders can participate in governance by staking their tokens and voting on proposals through our governance portal. One BTCY equals one vote, and proposals range from treasury allocations to new feature implementations.'
    }
  ];
  
  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? -1 : index);
  };
  
  return (
    <Card className="max-w-2xl mx-auto">
      <h3 className="font-orbitron text-xl text-center mb-6">Frequently Asked Questions</h3>
      <div>
        {faqs.map((faq, index) => (
          <FAQItem
            key={index}
            question={faq.question}
            answer={faq.answer}
            isOpen={openIndex === index}
            onClick={() => handleToggle(index)}
          />
        ))}
      </div>
    </Card>
  );
};