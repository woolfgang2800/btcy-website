import React from 'react';
import { Section } from './ui/Section';
import { Card } from './ui/Card';
import { Shield, TrendingUp, Coins as CoinStack, Coins } from 'lucide-react';
import { motion } from 'framer-motion';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Shield size={24} />,
      title: 'Asset-Backed Security',
      description: 'BTCY is backed by Bitcoin, gold (PAXG), and silver reserves, ensuring stability and intrinsic value.'
    },
    {
      icon: <TrendingUp size={24} />,
      title: 'Growth Potential',
      description: 'Participate in Bitcoin\'s growth while enjoying additional yield through our staking program.'
    },
    {
      icon: <CoinStack size={24} />,
      title: 'Yield Generation',
      description: 'Earn up to 25% APY through our advanced staking mechanism with flexible lock periods.'
    },
    {
      icon: <Coins size={24} />,
      title: 'Deflationary Model',
      description: 'Regular burn events reduce the total supply, potentially increasing value over time.'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 }
    }
  };

  return (
    <Section 
      title="Key Features" 
      subtitle="Discover what makes BTCY a unique and valuable crypto asset in the blockchain ecosystem."
    >
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 gap-6"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.1 }}
      >
        {features.map((feature, index) => (
          <motion.div key={index} variants={itemVariants}>
            <Card className="h-full" hoverEffect>
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4 flex-shrink-0">
                  <div className="text-primary">
                    {feature.icon}
                  </div>
                </div>
                <div>
                  <h3 className="font-orbitron text-lg text-white mb-2">{feature.title}</h3>
                  <p className="text-white/60">{feature.description}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </Section>
  );
};