import React from 'react';
import { StatCard } from './ui/StatCard';
import { Coins, Briefcase, Flame, Sparkles } from 'lucide-react';
import { Section } from './ui/Section';
import { motion } from 'framer-motion';

export const StatsSection: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 }
    }
  };

  return (
    <Section className="py-12">
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.1 }}
      >
        <motion.div variants={itemVariants}>
          <StatCard
            icon={<Coins size={24} />}
            title="Total Supply"
            value="100,000,000"
            subvalue="BTCY"
          />
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <StatCard
            icon={<Briefcase size={24} />}
            title="Backed By"
            value="Bitcoin_Gold_Silver"
            subvalue="Multi-asset reserve"
          />
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <StatCard
            icon={<Flame size={24} />}
            title="Burn Target"
            value="20%"
            subvalue="APY"
          />
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <StatCard
            icon={<Sparkles size={24} />}
            title="Use Cases"
            value="Yield staking"
            subvalue="governance & more"
          />
        </motion.div>
      </motion.div>
    </Section>
  );
};