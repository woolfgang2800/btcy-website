import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

export const TokenomicsChart: React.FC = () => {
  const data = {
    labels: ['Staking Rewards', 'Treasury', 'Team', 'Marketing', 'Liquidity', 'Burn Target'],
    datasets: [
      {
        data: [40, 20, 10, 10, 10, 10],
        backgroundColor: [
          '#D4AF37', // Gold - Primary
          '#4A00E0', // Deep purple - Secondary
          '#00B4FF', // Electric blue - Accent
          '#00C896', // Success
          '#FFB800', // Warning
          '#FF4A4A'  // Error
        ],
        borderColor: 'rgba(8, 8, 8, 0.5)',
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    cutout: '70%',
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: 'rgba(255, 255, 255, 0.7)',
          font: {
            family: 'Inter',
            size: 12
          },
          padding: 20,
          usePointStyle: true,
          pointStyle: 'circle'
        }
      },
      tooltip: {
        backgroundColor: 'rgba(8, 8, 8, 0.9)',
        titleColor: '#fff',
        bodyColor: 'rgba(255, 255, 255, 0.7)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        padding: 12,
        titleFont: {
          family: 'Orbitron',
          size: 14
        },
        bodyFont: {
          family: 'Inter',
          size: 12
        },
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.raw || 0;
            return `${label}: ${value}% (${(value / 100 * 100000000).toLocaleString()} BTCY)`;
          }
        }
      }
    },
  };

  return (
    <div className="relative">
      <div className="max-w-md mx-auto">
        <Doughnut data={data} options={options} />
      </div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
        <div className="font-orbitron text-primary text-2xl font-bold">100M</div>
        <div className="text-white/60 text-xs">Total Supply</div>
      </div>
    </div>
  );
};