import React, { useState, useEffect } from 'react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';

export const StakingCalculator: React.FC = () => {
  const [amount, setAmount] = useState('1000');
  const [period, setPeriod] = useState('30');
  const [apy, setApy] = useState(20);
  const [rewards, setRewards] = useState('0');
  const [connected, setConnected] = useState(false);
  
  useEffect(() => {
    // Calculate rewards based on amount, period, and APY
    const calculateRewards = () => {
      const amountValue = parseFloat(amount) || 0;
      const periodValue = parseInt(period) || 0;
      const dailyRate = apy / 365 / 100;
      const earned = amountValue * dailyRate * periodValue;
      
      setRewards(earned.toFixed(2));
    };
    
    calculateRewards();
  }, [amount, period, apy]);
  
  const handleConnectWallet = () => {
    setConnected(true);
  };
  
  return (
    <Card className="max-w-md mx-auto">
      <h3 className="font-orbitron text-xl text-center mb-6">Staking Calculator</h3>
      
      <div className="mb-4">
        <label className="block text-white/60 mb-2 text-sm">BTCY Amount</label>
        <div className="relative">
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40">BTCY</span>
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-white/60 mb-2 text-sm">Staking Period (Days)</label>
        <input
          type="range"
          min="1"
          max="365"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="w-full h-2 bg-background-dark rounded-lg appearance-none cursor-pointer accent-primary"
        />
        <div className="flex justify-between text-xs text-white/40 mt-1">
          <span>1 Day</span>
          <span>{period} Days</span>
          <span>365 Days</span>
        </div>
      </div>
      
      <div className="mb-6">
        <label className="block text-white/60 mb-2 text-sm">APY</label>
        <div className="flex justify-between gap-2">
          {[15, 20, 25].map((rate) => (
            <button
              key={rate}
              className={`flex-1 py-2 px-4 rounded-lg text-center ${
                apy === rate 
                  ? 'bg-primary text-background font-medium' 
                  : 'bg-background-dark text-white/60 hover:bg-background-light'
              }`}
              onClick={() => setApy(rate)}
            >
              {rate}%
            </button>
          ))}
        </div>
      </div>
      
      <div className="bg-background-dark rounded-lg p-4 mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-white/60">Staking Rewards:</span>
          <span className="font-orbitron text-primary">{rewards} BTCY</span>
        </div>
        <div className="flex justify-between">
          <span className="text-white/60">Total Value:</span>
          <span className="font-orbitron">{(parseFloat(amount) + parseFloat(rewards)).toFixed(2)} BTCY</span>
        </div>
      </div>
      
      {!connected ? (
        <Button 
          variant="primary" 
          className="w-full"
          onClick={handleConnectWallet}
        >
          Connect Wallet
        </Button>
      ) : (
        <Button 
          variant="primary" 
          className="w-full"
        >
          Stake Now
        </Button>
      )}
    </Card>
  );
};