import React, { useState } from 'react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';

export const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission
    setTimeout(() => {
      setIsSubmitted(true);
    }, 500);
  };

  return (
    <Card className="max-w-xl mx-auto">
      {!isSubmitted ? (
        <form onSubmit={handleSubmit}>
          <h3 className="font-orbitron text-xl text-center mb-6">Contact Us</h3>
          
          <div className="mb-4">
            <label className="block text-white/60 mb-2 text-sm">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-white/60 mb-2 text-sm">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-white/60 mb-2 text-sm">Subject</label>
            <select
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
            >
              <option value="">Select a subject</option>
              <option value="investment">Investment Opportunity</option>
              <option value="partnership">Partnership</option>
              <option value="technical">Technical Support</option>
              <option value="other">Other</option>
            </select>
          </div>
          
          <div className="mb-6">
            <label className="block text-white/60 mb-2 text-sm">Message</label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              rows={5}
              className="w-full bg-background border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60 resize-none"
            ></textarea>
          </div>
          
          <Button type="submit" variant="primary" className="w-full">
            Send Message
          </Button>
        </form>
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="font-orbitron text-xl mb-2">Message Sent!</h3>
          <p className="text-white/60 mb-6">
            Thank you for contacting us. We will get back to you as soon as possible.
          </p>
          <Button variant="primary" onClick={() => setIsSubmitted(false)} className="w-full">
            Send Another Message
          </Button>
        </div>
      )}
    </Card>
  );
};