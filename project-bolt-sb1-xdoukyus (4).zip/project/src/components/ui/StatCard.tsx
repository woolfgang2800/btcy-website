import React from 'react';
import { Card } from './Card';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  subvalue?: string;
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ icon, title, value, subvalue, className = '' }) => {
  return (
    <Card className={`${className}`}>
      <div className="flex items-start">
        <div className="bg-primary/10 p-3 rounded-full mr-4">
          <div className="text-primary">
            {icon}
          </div>
        </div>
        <div>
          <h3 className="text-white/60 text-sm font-orbitron tracking-wide mb-1">{title}</h3>
          <p className="text-2xl font-orbitron text-white">{value}</p>
          {subvalue && <p className="text-white/40 text-xs mt-1">{subvalue}</p>}
        </div>
      </div>
    </Card>
  );
};