import React, { ElementType, ComponentPropsWithoutRef } from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost';
type ButtonSize = 'sm' | 'md' | 'lg';

type ButtonProps<T extends ElementType> = {
  as?: T;
  variant?: ButtonVariant;
  size?: ButtonSize;
  children: React.ReactNode;
  className?: string;
} & ComponentPropsWithoutRef<T>;

export const Button = <T extends ElementType = 'button'>({
  as,
  variant = 'primary',
  size = 'md',
  children,
  className = '',
  ...props
}: ButtonProps<T>) => {
  const Component = as || 'button';

  const baseClasses = 'inline-flex items-center justify-center font-orbitron rounded transition-all focus:outline-none focus:ring-2 focus:ring-primary/50';
  
  const variantClasses = {
    primary: 'bg-primary text-background hover:bg-primary/90 border border-primary',
    secondary: 'bg-secondary text-white hover:bg-secondary/90 border border-secondary',
    outline: 'bg-transparent text-primary hover:bg-primary/10 border border-primary',
    ghost: 'bg-transparent text-white hover:bg-white/10 border border-transparent',
  };

  const sizeClasses = {
    sm: 'text-xs px-4 py-1.5 tracking-wider',
    md: 'text-sm px-6 py-2 tracking-wider',
    lg: 'text-base px-8 py-3 tracking-wider',
  };

  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`;

  return (
    <Component className={classes} {...props}>
      {children}
    </Component>
  );
};