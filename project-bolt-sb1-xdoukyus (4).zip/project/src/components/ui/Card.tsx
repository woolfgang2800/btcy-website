import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
}

export const Card: React.FC<CardProps> = ({ children, className = '', hoverEffect = false }) => {
  return (
    <div 
      className={`
        bg-background-light border border-white/10 rounded-lg p-6 
        relative overflow-hidden
        ${hoverEffect ? 'transition-transform hover:scale-[1.02] hover:shadow-[0_0_15px_rgba(212,175,55,0.15)]' : ''}
        ${className}
      `}
    >
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};