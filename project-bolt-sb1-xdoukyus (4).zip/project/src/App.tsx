import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { TokenomicsPage } from './pages/TokenomicsPage';
import { StakingPage } from './pages/StakingPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { WhitepaperPage } from './pages/WhitepaperPage';
import { ContactPage } from './pages/ContactPage';
import { LoadingScreen } from './components/LoadingScreen';
import ScrollToTop from './utils/ScrollToTop';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Router>
      <ScrollToTop />
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/tokenomics" element={<TokenomicsPage />} />
          <Route path="/staking" element={<StakingPage />} />
          <Route path="/onboarding" element={<OnboardingPage />} />
          <Route path="/whitepaper" element={<WhitepaperPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;