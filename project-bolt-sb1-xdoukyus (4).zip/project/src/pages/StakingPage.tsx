import React from 'react';
import { Section } from '../components/ui/Section';
import { Card } from '../components/ui/Card';
import { StakingCalculator } from '../components/StakingCalculator';
import { Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export const StakingPage: React.FC = () => {
  const stakingOptions = [
    {
      title: 'Flexible Staking',
      apy: '15%',
      lockPeriod: 'No lock',
      minAmount: '100 BTCY',
      features: ['Withdraw anytime', 'Daily rewards', 'Lower APY rate'],
      recommended: false,
    },
    {
      title: 'Standard Staking',
      apy: '20%',
      lockPeriod: '30 days',
      minAmount: '500 BTCY',
      features: ['Medium-term commitment', 'Automatic compounding', 'Moderate APY rate'],
      recommended: true,
    },
    {
      title: 'Premium Staking',
      apy: '25%',
      lockPeriod: '90 days',
      minAmount: '1,000 BTCY',
      features: ['Long-term commitment', 'Highest APY rate', 'Governance rights'],
      recommended: false,
    },
  ];

  return (
    <div className="pt-20">
      <Section title="Stake BTCY, Earn Yield" subtitle="Grow your BTCY holdings through our staking program with high-yield rewards">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="order-2 lg:order-1"
          >
            <StakingCalculator />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 lg:order-2"
          >
            <h3 className="font-orbitron text-2xl mb-6">How Staking Works</h3>
            <div className="space-y-6">
              <div className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">1</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-orbitron text-lg text-white mb-2">Connect Your Wallet</h4>
                  <p className="text-white/60">
                    Link your compatible wallet (MetaMask, Trust Wallet, etc.) to our staking platform.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">2</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-orbitron text-lg text-white mb-2">Choose Staking Option</h4>
                  <p className="text-white/60">
                    Select the staking plan that fits your needs based on lock period and APY rate.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">3</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-orbitron text-lg text-white mb-2">Stake Your BTCY</h4>
                  <p className="text-white/60">
                    Deposit your BTCY tokens into the staking contract. You'll receive a confirmation transaction.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">4</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-orbitron text-lg text-white mb-2">Earn Rewards</h4>
                  <p className="text-white/60">
                    Watch your BTCY grow as rewards are distributed daily. Claim or compound at any time.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Section>

      <Section title="Staking Options" subtitle="Choose the staking plan that best suits your investment strategy">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stakingOptions.map((option, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full relative overflow-hidden" hoverEffect>
                {option.recommended && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-primary text-background text-xs font-orbitron py-1 px-3 shadow-lg">
                      Recommended
                    </div>
                  </div>
                )}
                <h3 className="font-orbitron text-xl text-white mb-4">{option.title}</h3>
                <div className="flex items-baseline mb-6">
                  <span className="text-3xl font-orbitron text-primary">{option.apy}</span>
                  <span className="text-white/60 ml-1">APY</span>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center">
                    <Clock size={16} className="text-primary mr-2" />
                    <span className="text-white/70">Lock Period: {option.lockPeriod}</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={16} className="text-primary mr-2" />
                    <span className="text-white/70">Min. Amount: {option.minAmount}</span>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white font-semibold mb-2">Features</h4>
                  <ul className="space-y-2">
                    {option.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <AlertCircle size={16} className="text-primary mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-white/60 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>
    </div>
  );
};