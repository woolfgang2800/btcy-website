import React from 'react';
import { Section } from '../components/ui/Section';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { FileText, Download, FileSearch, BarChart } from 'lucide-react';
import { motion } from 'framer-motion';

export const WhitepaperPage: React.FC = () => {
  const documents = [
    {
      title: 'BTCY Whitepaper',
      version: 'v1.2',
      description: 'Comprehensive overview of the BTCY project, including tokenomics, technology, and roadmap.',
      icon: <FileText size={24} />,
      buttonText: 'Download Whitepaper',
    },
    {
      title: 'Tokenomics Sheet',
      version: 'v1.0',
      description: 'Detailed breakdown of token distribution, vesting schedules, and burn mechanism.',
      icon: <BarChart size={24} />,
      buttonText: 'Download Tokenomics',
    },
    {
      title: 'Audit Report',
      version: 'March 2025',
      description: 'Security audit conducted by CertiK, validating smart contract security and identifying risks.',
      icon: <FileSearch size={24} />,
      buttonText: 'Download Audit',
    },
  ];

  const roadmap = [
    {
      phase: 'Phase 1: Launch',
      period: 'Q2 2025',
      items: [
        'Initial token distribution',
        'Exchange listings',
        'Staking platform launch',
        'Community building',
      ]
    },
    {
      phase: 'Phase 2: Expansion',
      period: 'Q3-Q4 2025',
      items: [
        'Advanced governance implementation',
        'Strategic partnerships',
        'First quarterly burn event',
        'Enhanced security audits',
      ]
    },
    {
      phase: 'Phase 3: Ecosystem Growth',
      period: '2026',
      items: [
        'AI accounting system launch',
        'Cross-chain interoperability',
        'Institutional investor program',
        'Reserve expansion (additional assets)',
      ]
    },
    {
      phase: 'Phase 4: Final Supply Cap',
      period: '2027',
      items: [
        'Enterprise solutions integration',
        'Decentralized exchange launch',
        'Global regulatory compliance framework',
        'Supply cap target achievement (21M)',
      ]
    },
  ];

  return (
    <div className="pt-20">
      <Section title="Whitepaper & Documents" subtitle="Access official documentation and research on the BTCY project">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {documents.map((doc, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full flex flex-col" hoverEffect>
                <div className="mb-4">
                  <div className="bg-primary/10 p-3 rounded-full inline-flex items-center justify-center">
                    <div className="text-primary">
                      {doc.icon}
                    </div>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-orbitron text-lg text-white">{doc.title}</h3>
                    <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded">
                      {doc.version}
                    </span>
                  </div>
                  <p className="text-white/60 mb-6">
                    {doc.description}
                  </p>
                </div>
                <Button variant="outline" size="sm" className="w-full mt-auto flex items-center justify-center gap-2">
                  <Download size={16} />
                  {doc.buttonText}
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <div className="flex justify-center mt-8">
          <Button variant="primary" className="flex items-center gap-2">
            <Download size={18} />
            Download All Documents
          </Button>
        </div>
      </Section>

      <Section title="Company Roadmap" subtitle="Our strategic plan for growth and development from 2025 to 2027">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card>
              <div className="space-y-12">
                {roadmap.map((phase, index) => (
                  <div key={index} className="relative">
                    {index < roadmap.length - 1 && (
                      <div className="absolute bottom-0 left-[98px] h-12 w-px bg-gradient-to-b from-primary/50 to-transparent"></div>
                    )}
                    <div className="flex">
                      <div className="w-24 flex-shrink-0">
                        <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center font-orbitron text-primary text-sm text-center">
                          {phase.period}
                        </div>
                      </div>
                      <div>
                        <h3 className="font-orbitron text-xl text-white mb-3">{phase.phase}</h3>
                        <ul className="space-y-2">
                          {phase.items.map((item, i) => (
                            <li key={i} className="flex items-start">
                              <span className="text-primary mr-2">•</span>
                              <span className="text-white/70">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </Section>
    </div>
  );
};