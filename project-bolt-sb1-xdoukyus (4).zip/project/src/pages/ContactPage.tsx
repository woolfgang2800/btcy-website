import React from 'react';
import { Section } from '../components/ui/Section';
import { ContactForm } from '../components/ContactForm';
import { FAQ } from '../components/FAQ';
import { motion } from 'framer-motion';

export const ContactPage: React.FC = () => {
  return (
    <div className="pt-20">
      <Section title="Contact / Investor Page" subtitle="Get in touch with our team for investment opportunities or support">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <ContactForm />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <FAQ />
          </motion.div>
        </div>
      </Section>

      <Section title="Investor Resources" subtitle="Schedule a meeting or access additional materials">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-[url('https://images.pexels.com/photos/7788009/pexels-photo-7788009.jpeg?auto=compress&cs=tinysrgb&w=1200')] bg-cover bg-center rounded-lg overflow-hidden"
          >
            <div className="bg-background/80 backdrop-blur-sm p-8 md:p-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="font-orbitron text-2xl text-white mb-4">Schedule a Meeting</h3>
                  <p className="text-white/70 mb-6">
                    Interested in learning more about BTCY investment opportunities? Schedule a one-on-one call with our investor relations team.
                  </p>
                  <div className="space-y-4">
                    <div className="bg-background/40 rounded-lg p-4 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-success mr-3"></div>
                      <span className="text-white">Available: Weekdays 9 AM - 5 PM UTC</span>
                    </div>
                    <div className="bg-background/40 rounded-lg p-4 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-primary mr-3"></div>
                      <span className="text-white">Response time: Within 24 hours</span>
                    </div>
                  </div>
                </div>
                <div className="bg-background/60 backdrop-blur-sm rounded-lg p-6">
                  <h4 className="font-orbitron text-lg text-center mb-4">Book Your Appointment</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-white/80 mb-2 text-sm">Your Name</label>
                      <input
                        type="text"
                        className="w-full bg-background/70 border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
                      />
                    </div>
                    <div>
                      <label className="block text-white/80 mb-2 text-sm">Your Email</label>
                      <input
                        type="email"
                        className="w-full bg-background/70 border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
                      />
                    </div>
                    <div>
                      <label className="block text-white/80 mb-2 text-sm">Preferred Date</label>
                      <input
                        type="date"
                        className="w-full bg-background/70 border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:border-primary/60"
                      />
                    </div>
                    <button className="w-full bg-primary text-background py-3 rounded-lg font-orbitron tracking-wider hover:bg-primary/90 transition-colors">
                      Schedule Call
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Section>
    </div>
  );
};