import React from 'react';
import { Section } from '../components/ui/Section';
import { Card } from '../components/ui/Card';
import { TokenomicsChart } from '../components/TokenomicsChart';
import { motion } from 'framer-motion';

export const TokenomicsPage: React.FC = () => {
  const tokenData = [
    { title: 'Initial Supply', value: '100,000,000 BTCY' },
    { title: 'Final Target', value: '21,000,000 BTCY' },
    { title: 'Burn Rate', value: '2% per quarter' },
    { title: 'Staking Rewards', value: '15-25% APY' },
    { title: 'Treasury Allocation', value: '20% of total supply' },
  ];

  const timeline = [
    { year: '2025', event: 'Initial Token Launch', description: 'Launch of BTCY with 100M initial supply' },
    { year: '2025 Q4', event: 'First Major Burn', description: 'Burn 10M tokens from treasury' },
    { year: '2026 Q2', event: 'Enhanced Staking', description: 'Implementation of tiered staking rewards' },
    { year: '2026 Q4', event: 'Supply Reduction', description: 'Reach 50M total supply milestone' },
    { year: '2027', event: 'Final Supply Cap', description: 'Achieve final target of 21M BTCY' },
  ];

  return (
    <div className="pt-20">
      <Section title="Tokenomics" subtitle="Understand the economic model and distribution of BTCY tokens">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Card>
              <h3 className="font-orbitron text-xl mb-6">Token Distribution</h3>
              <TokenomicsChart />
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card>
              <h3 className="font-orbitron text-xl mb-6">Token Metrics</h3>
              <div className="space-y-4">
                {tokenData.map((item, index) => (
                  <div key={index} className="flex justify-between pb-2 border-b border-white/10 last:border-b-0 last:pb-0">
                    <span className="text-white/70">{item.title}</span>
                    <span className="font-orbitron text-primary">{item.value}</span>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </Section>

      <Section title="Burn Schedule" subtitle="BTCY implements a deflationary model with regular burn events to reduce supply">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <Card>
            <div className="relative">
              <div className="absolute top-0 left-0 w-1 h-full bg-primary/30 ml-7"></div>
              <div className="space-y-8">
                {timeline.map((item, index) => (
                  <div key={index} className="flex">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full bg-background-dark border-2 border-primary flex items-center justify-center font-orbitron text-primary z-10">
                        {item.year}
                      </div>
                    </div>
                    <div className="ml-8 pt-2">
                      <h3 className="font-orbitron text-lg text-white">{item.event}</h3>
                      <p className="text-white/60 mt-1">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
      </Section>

      <Section title="Use Cases" subtitle="BTCY has multiple utilities within the ecosystem">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="h-full" hoverEffect>
              <h3 className="font-orbitron text-lg text-white mb-4">Yield Staking</h3>
              <p className="text-white/60 mb-4">
                Stake BTCY tokens to earn high yields with APY rates ranging from 15% to 25% based on lock periods.
              </p>
              <ul className="list-disc list-inside text-white/60 space-y-2">
                <li>Flexible staking periods</li>
                <li>Daily reward distributions</li>
                <li>Compounding options</li>
              </ul>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="h-full" hoverEffect>
              <h3 className="font-orbitron text-lg text-white mb-4">Governance</h3>
              <p className="text-white/60 mb-4">
                BTCY holders can participate in governance decisions, voting on proposals that shape the future of the protocol.
              </p>
              <ul className="list-disc list-inside text-white/60 space-y-2">
                <li>Proposal voting rights</li>
                <li>Treasury allocation decisions</li>
                <li>Protocol upgrades</li>
              </ul>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <Card className="h-full" hoverEffect>
              <h3 className="font-orbitron text-lg text-white mb-4">AI Accounting</h3>
              <p className="text-white/60 mb-4">
                Our innovative AI accounting system automates portfolio tracking, tax calculations, and yield projections.
              </p>
              <ul className="list-disc list-inside text-white/60 space-y-2">
                <li>Automated tax reporting</li>
                <li>Yield optimization strategies</li>
                <li>Real-time portfolio analysis</li>
              </ul>
            </Card>
          </motion.div>
        </div>
      </Section>
    </div>
  );
};