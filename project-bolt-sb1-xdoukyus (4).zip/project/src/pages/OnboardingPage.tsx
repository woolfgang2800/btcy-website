import React from 'react';
import { Section } from '../components/ui/Section';
import { KYCForm } from '../components/KYCForm';
import { motion } from 'framer-motion';

export const OnboardingPage: React.FC = () => {
  return (
    <div className="pt-20">
      <Section title="Investor Onboarding Made Easy" subtitle="Get started in minutes, verify your identity and make your first investment">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <KYCForm />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="space-y-8">
              <div>
                <h3 className="font-orbitron text-2xl mb-4">Why KYC?</h3>
                <p className="text-white/70 mb-4">
                  At BTCY, we're committed to maintaining the highest standards of regulatory compliance and security. Our KYC process helps us:
                </p>
                <ul className="space-y-2">
                  <li className="flex">
                    <span className="text-primary mr-2">•</span>
                    <span className="text-white/70">Prevent fraud and unauthorized access</span>
                  </li>
                  <li className="flex">
                    <span className="text-primary mr-2">•</span>
                    <span className="text-white/70">Comply with global anti-money laundering (AML) regulations</span>
                  </li>
                  <li className="flex">
                    <span className="text-primary mr-2">•</span>
                    <span className="text-white/70">Ensure a secure environment for all investors</span>
                  </li>
                  <li className="flex">
                    <span className="text-primary mr-2">•</span>
                    <span className="text-white/70">Provide enhanced support and services to verified users</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="font-orbitron text-2xl mb-4">What to Expect</h3>
                <p className="text-white/70 mb-4">
                  Our KYC process is simple, secure, and typically takes less than 48 hours to complete:
                </p>
                <ol className="space-y-4">
                  <li className="flex">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-primary font-bold">1</span>
                    </div>
                    <div>
                      <h4 className="font-orbitron text-white mb-1">Personal Information</h4>
                      <p className="text-white/60 text-sm">Provide basic details like name, email, and country of residence</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-primary font-bold">2</span>
                    </div>
                    <div>
                      <h4 className="font-orbitron text-white mb-1">Wallet Connection</h4>
                      <p className="text-white/60 text-sm">Link your cryptocurrency wallet to verify ownership</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-primary font-bold">3</span>
                    </div>
                    <div>
                      <h4 className="font-orbitron text-white mb-1">Verification Review</h4>
                      <p className="text-white/60 text-sm">Our team will review your submission and approve your account</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-primary font-bold">4</span>
                    </div>
                    <div>
                      <h4 className="font-orbitron text-white mb-1">Start Investing</h4>
                      <p className="text-white/60 text-sm">Once approved, you can stake BTCY and access all platform features</p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </motion.div>
        </div>
      </Section>
    </div>
  );
};