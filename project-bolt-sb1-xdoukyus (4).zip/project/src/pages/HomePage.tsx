import React from 'react';
import { HeroSection } from '../components/HeroSection';
import { StatsSection } from '../components/StatsSection';
import { FeaturesSection } from '../components/FeaturesSection';
import { Section } from '../components/ui/Section';
import { Button } from '../components/ui/Button';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <StatsSection />
      <FeaturesSection />
      
      <Section className="bg-background-dark py-24">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="font-orbitron text-3xl md:text-4xl font-bold mb-6">
              Ready to <span className="text-primary">Start Your Journey</span> with BTCY?
            </h2>
            <p className="text-white/70 mb-8 max-w-2xl mx-auto">
              Join thousands of investors already benefiting from our innovative, asset-backed cryptocurrency. Start staking today and earn high yields while participating in Bitcoin's growth.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button as={Link} to="/onboarding" variant="primary" size="lg">
                Get Started
              </Button>
              <Button as={Link} to="/whitepaper" variant="outline" size="lg">
                Read Whitepaper
              </Button>
            </div>
          </motion.div>
        </div>
      </Section>
    </div>
  );
};